package Package1;

public class Student {
    private String studentID;
    public Student(String studentID){
        this.studentID = studentID;
    }
    public String toString() {
        return studentID;
    }


}
